# R version 3.3.2 (2016-10-31)
#library(matlib)
library(matrixcalc)
#library(ComplexHeatmap)
library(Rtsne)
#library(scmamp)
library(robustbase)
library(philentropy)
#library(qgraph)
#library(sparsesvd)
#library(ggcorrplot)
#library(nFactors)

library(stringr)
library(mlr)
library(caret)

library(tsne)
library(e1071) # naive bayes
library(randomForest)

#library(DMwR) # kNN

library(R.matlab)
library(shapper)



get_best_coco <- function(folder, best){
  all_best <- c()
  sample_size = 250
  files <- list.files(folder, full.names = FALSE, pattern = toString(sample_size))
  pattern <- ("(\\d+)_(\\d+)_.*")
  for (file in files){
    regex_match <- str_match(file, pattern)
    func <- regex_match[1,2]
    instance <- regex_match[1,3]
    best_index <- ((as.numeric(func) - 1) * 15) + as.numeric(instance)
    file_best <- best[best_index]
    all_best <- c(all_best, file_best)
  }
  return(all_best)
}


linear_matrix_factorization_embeddings<-function(X_temp,problems_names,number_of_singular_values){
  
  data_temp<-X_temp
  decomposition<-svd(data_temp)
  
  
  Sigma<-diag(decomposition$d[1:number_of_singular_values])
  U<-decomposition$u[,1:number_of_singular_values]
  V_t<-t(decomposition$v)[1:number_of_singular_values,]
  inv_Sigma<-diag(1/decomposition$d[1:number_of_singular_values])
  problem_embeddings<-list()
  
  for(i in 1:nrow(data_temp)){
    problem_embeddings[[i]]<-data_temp[i,]%*%t(V_t)%*%inv_Sigma
  }
  problems_embeded<-matrix(unlist(problem_embeddings)[!is.na(unlist(problem_embeddings))], ncol = length(problem_embeddings[[i]]), byrow = T)
  
  rownames(problems_embeded)<-problems_names
  return(list(problems_embeded=problems_embeded,U=U,Sigma=Sigma,V_t=V_t))
  
}

normalize_data <- function(df, means = NA, stds = NA, min = NA, max = NA, type="normalize") {
  #TODO: Poglej kje se to razlikuje
  classes <- df$class
  df$class <- NULL
  
  funcs <- df$func
  df$func <- NULL
  
  #print("In normalize_data")
  #df<- normalizeFeatures(df)
  
  
  #does the same as above, but allows us to save the normalization parameters
  #and use them for other data
  df2 <- as.data.frame(df)
  
  columns <- colnames(df2)
  #saveRDS(columns, "columns")
  if(is.na(means)){
    means <- colMeans(df2)
    saveRDS(means, "means")
  }
  
  
  if(is.na(stds)){
    stds <- apply(df2, 2, sd)
    saveRDS(stds, "stds")
  }
  
  if(is.na(min)){
    min <- apply(df2, 2, min)
    saveRDS(min, "max")
  }
  
  if(is.na(max)){
    max <- apply(df2, 2, max)
    saveRDS(max, "max")
  }
  
  if(type == "normalize" || type=="both"){
    df2 <- sweep(df2, 2, means, FUN = '-')
    df2 <- sweep(df2, 2, stds, FUN = '/')
  }
  
  if (type =="minmax" || type == "both"){
    df2 <- sweep(df2, 2, min, FUN = '-')
    df2 <- sweep(df2, 2, (max-min), FUN = '/')
  }
  
  ret <- c()
  ret$normalized <- df2
  ret$mean <- means
  ret$std <- stds
  df2$class <- classes
  df2$func <- funcs
  
  #remove constant columns that have been set to NaN during normalization
  df2 <- df2[ , colSums(is.na(df2)) == 0]
  df2 <- df2[ , colSums(is.nan(df2)) == 0]
  return(df2)
}

read_features_performance <- function(folder = "C:\\R_Code\\samples_10D\\features", sample_size = 250){
  #files <- list.files(folder, full.names = TRUE, pattern = paste(".+_samples_.+_",sample_size,"_", sep=""))
  files <- list.files(folder, full.names = TRUE, pattern = paste(sample_size, sep=""))
  allData <- NULL
  allBest <- c()
  i<-1
  for (file in files){
    #get class based on file name
    pattern <- "samples_(\\D*)_"
    res <- str_match(file, pattern)
    best_algorithm <- res[1,2]
    allBest <- c(allBest, best_algorithm)
    
    pattern_function <- ".+_(\\d*)_samples_"
    res <- str_match(file, pattern_function)
    file_function <- as.numeric(res[1,2])
    i <- i + 1
    
    data <- readRDS(file)
    columns <- readRDS("ML_cols.RDS")
    if (is.null(allData)){
      allData <- matrix(nrow = 0, ncol = length(columns))
    }
    data$func <- file_function
    columns <- readRDS("ML_cols.RDS")
    data <- unlist(data)
    data <- data[columns]
    allData <- rbind(allData,unlist(data))
    #if(!is.null(colnames(allData)) && (colnames(allData) != names(data))){
    #  print("NAME MISMATCH")
    #}
    #colnames(allData) <- names(data)
  }
  result <- c()
  result$data = allData
  result$best = allBest
  return(result)
}


read_features_performance_coco <- function(folder = "C:\\R_Code\\samples_10D\\features", sample_size = 250){
  #files <- list.files(folder, full.names = TRUE, pattern = paste(".+_samples_.+_",sample_size,"_", sep=""))
  files <- list.files(folder, full.names = TRUE, pattern = toString(sample_size))
  allData <- NULL
  allBest <- c()
  for (file in files){
    #get class based on file name
    pattern <- "samples_(\\D*)_"
    res <- str_match(file, pattern)
    best_algorithm <- res[1,2]
    allBest <- c(allBest, best_algorithm)
    
    pattern_function <- ".+_(\\d*)_.*_250.mat.RDS"
    res <- str_match(file, pattern_function)
    file_function <- as.numeric(res[1,2])
    
    trial_function <- ".+_.+_(\\d*)_250.mat.RDS"
    res <- str_match(file, trial_function)
    trial <- as.numeric(res[1,2])
    
    if (trial > 10){
      next()
    }
    
    
    
    data <- readRDS(file)
    if (is.null(allData)){
      allData <- matrix(nrow = 0, ncol = length(data) + 1)
    }
    data$func <- file_function
    columns <- readRDS("E:\\ML_Samples\\features\\ML_cols.RDS")
    data <- unlist(data)
    data <- data[columns]
    
    allData <- rbind(allData,unlist(data))
    #if(!is.null(colnames(allData)) && (colnames(allData) != names(data))){
    #  print("NAME MISMATCH")
    #}
    #colnames(allData) <- names(data)
  }
  result <- c()
  result$data = allData
  result$best = allBest
  return(result)
}

#Create k folds, so that all runs of a function are always in the same fold (create folds based on functions)
createFoldsCustom <- function(data, k){
  #print(data)
  
  folds = 10
  funcs <- unique(data$func)
  times <- rep(length(funcs)/folds, folds)
  indices <- sample(rep(1:folds, times = times))
  splits <- split(funcs, indices)
  
  all_indexes <- c()
  i <- 1
  for (split in splits){
    indexes <- which(data$func %in% split)
    all_indexes[[i]] <- indexes
    i <- i + 1
  }
  return(all_indexes)
  
}


train_ml <- function(ml_func, train_data){
  model <- c()
  model$all = ml_func(train_data$all)
  model$"2" = ml_func(train_data$"2")
  model$"5" = ml_func(train_data$"5")
  model$"10" = ml_func(train_data$"10")
  model$"15" = ml_func(train_data$"15")
  model$"20" = ml_func(train_data$"20")
  model$Cols = ml_func(train_data$Cols)
  
  return(model)
}
test_ml <- function(model, test_data, validation_data, model_name, train_data, predictor = function(x,y){predict(x,y, predcontrib = TRUE, approxcontrib = F)}){
  accuracy <- list()
  precisions <- list()
  recalls <- list()
  f1s <- list()
  
  #model_names <- c("all", "2", "5", "10", "15", "20", "Cols")
  model_names <- c("all")
  
  for (m in model_names){
    train <- train_data[[m]]
    validation <- validation_data
    predictions <- predictor(model[[m]], test_data)
    predictions_validate <- predictor(model[[m]], validation)
    t<-table(predictions, test_data$class)
    accuracy[[m]] <- sum(diag(t))/sum(t)
    
    correct <- diag(t) # the correct predictions are on the diagonals
    total_cols <- colSums(t)
    total_rows <- rowSums(t)
    
    precisions[[m]] <-  correct / total_rows
    recalls[[m]] <- correct / total_cols
    fp <- total_rows - correct
    fn <- total_cols - correct
    #f1s[[m]] <- 2*((precisions[[m]]*recalls[[m]]) / (precisions[[m]] + recalls[[m]] ))
    #f1s[[m]] <- 2*(((correct / total_rows)*(correct / total_cols)) / ((correct / total_rows)+ (correct / total_cols) ))
    f1s[[m]] <- (2*correct) / (2*correct + fp + fn) #isto kot zgoraj. Isto kot prva enačba, samo da je 0 namesto NaN ko sta precision in recall oba 0 (drugače da f1 večje kot precision in recall ko damo macro average)
    
    
    #explanation
    #train_samples <- sample(nrow(train), 100)
    #train_samples <- train[train_samples, ]
    #exp_rf <- explain(model[[m]], data = train_samples)
    #exp_rf <- explain(model[[m]], data = train)
    
   
      #print(paste("SHAP", i, sep=": "))
      train_data <- train
      train_data$class <- NULL
      explain_data <- test
      explain_classes <- explain_data$class
      explain_data$class <- NULL
      p_function <- function(model, data) predict(model, newdata = data, type = "prob")
      ive_rf <- individual_variable_effect(model[[m]], data = train_data, predict_function = p_function,
                                           new_observation = explain_data, nsamples = as.integer(250))
      
      
      
      
      #ive_rf <- shap(exp_rf, new_observation = test_data[1,], nsamples = as.integer(1000))
      #ive_rf <- shap(exp_rf, new_observation = test_data, nsamples = as.integer(1000))
      shap_values <- c()
      shap_matrix <- matrix(nrow=0,ncol=ncol(train_data))
      
      shap_values_correct <- list()
      shap_matrix_correct <- matrix(nrow=0,ncol=ncol(train_data))
      
      shap_values_wrong <- list()
      shap_matrix_wrong <- matrix(nrow=0,ncol=ncol(train_data))
      for (i_class in 1:10){
        to_select <- which(predictions == i_class)
        ive_rf_filtered <- ive_rf[ive_rf$'_id_' %in% to_select, ] #take only the explanations for the 
        ive_rf_filtered <- ive_rf_filtered[ive_rf_filtered$'_ylevel_' ==i_class, ] #take only the explanations for the 
        filtered_classes <- explain_classes[to_select]
        #each explain instance will have 50 rows (one per feature)
        filtered_classes <- rep(filtered_classes, each = 50)
        #shapper:::plot.individual_variable_effect(ive_rf_filtered, show_predicted = FALSE, id=1)
        #shapper:::print.individual_variable_effect(ive_rf_filtered, id=1)
        attributions <- ive_rf_filtered$'_attribution_'
        correct <- ive_rf_filtered$'_ylevel_' == filtered_classes
        wrong <- !correct
        num_features <- ncol(train_data)
        
        attribution_mat <- matrix(attributions, ncol=num_features)
        colnames(attribution_mat) <- colnames(train_data)
        shap_values <- colMeans(attribution_mat)
        shap_matrix<-rbind(shap_matrix, t(shap_values))
        
        attribution_mat_correct <- matrix(attributions[correct], ncol=num_features)
        colnames(attribution_mat) <- colnames(train_data)
        shap_values_correct <- colMeans(attribution_mat_correct)
        shap_matrix_correct<-rbind(shap_matrix_correct, t(shap_values_correct))
        
        attribution_mat_wrong <- matrix(attributions[wrong], ncol=num_features)
        colnames(attribution_mat_wrong) <- colnames(train_data)
        shap_values_wrong <- colMeans(attribution_mat_wrong)
        shap_matrix_wrong<-rbind(shap_matrix_wrong, t(shap_values_wrong))
        
        #filtered_correct <- 
        
      }
      print("DONE")
      ret <- c()
      ret$all <- shap_matrix
      ret$correct <- shap_matrix_correct
      ret$wrong <- shap_matrix_wrong
      return(ret)
  }
  
    

  
  
  
  
  accuracy <- unlist(accuracy)
  names(accuracy) <-  paste(model_name, names(accuracy), sep = "_")
  
  #table is: rows = prediction, columns = true
  
  
  results <- c()
  results$accuracy <- accuracy
  results$precision <- precisions
  results$recall <- recalls
  results$f1 <- f1s
  
  return(results)
  
}

test_ml_old <- function(model, test_data, model_name, predictor = function(x,y){predict(x,y)}){
  accuracy <- c()
  
  predictions <- predictor(model$all, test_data)
  predictions2 <- predictor(model$"2", test_data)
  predictions5 <- predictor(model$"5", test_data)
  predictions10 <- predictor(model$"10", test_data)
  predictions15 <- predictor(model$"15", test_data)
  predictions20 <- predictor(model$"20", test_data)
  predictionsCols <- predictor(model$Cols, test_data)
  
  
  t2<-table(predictions2, test_data$class)
  accuracy$"2" <- sum(diag(t2))/sum(t2)
  
  t5<-table(predictions5, test_data$class)
  accuracy$"5" <- sum(diag(t5))/sum(t5)
  
  t10<-table(predictions10, test_data$class)
  accuracy$"10" <- sum(diag(t10))/sum(t10)
  
  t15<-table(predictions15, test_data$class)
  accuracy$"15" <- sum(diag(t15))/sum(t15)
  
  t20<-table(predictions20, test_data$class)
  accuracy$"20" <- sum(diag(t20))/sum(t20)
  
  tall<-table(predictions, test_data$class)
  accuracy$"all" <- sum(diag(tall))/sum(tall)
  
  tCols<-table(predictionsCols, test_data$class)
  accuracy$"Cols" <- sum(diag(tCols))/sum(tCols)
  
  accuracy <- unlist(accuracy)
  names(accuracy) <-  paste(model_name, names(accuracy), sep = "_")
  
  return(accuracy)
  
}

get_func_coco <- function(folder, best){
  all_best <- c()
  sample_size = 250
  files <- list.files(folder, full.names = FALSE, pattern = toString(sample_size))
  pattern <- ("(\\d+)_(\\d+)_.*")
  for (file in files){
    trial_function <- ".+_.+_(\\d*)_250.mat.RDS"
    res <- str_match(file, trial_function)
    trial <- as.numeric(res[1,2])
    if (trial > 10){
      next()
    }
    regex_match <- str_match(file, pattern)
    func <- regex_match[1,2]
    instance <- regex_match[1,3]
    #func_coco <- as.numeric(func)*100 + as.numeric(instance)
    func_coco <- as.numeric(func)*100
    all_best <- c(all_best, func_coco)
  }
  return(all_best)
}



analyze_results <- function(results){
  accuracy <- matrix(nrow = 0, ncol = length(results[[1]][[1]]$accuracy))
  precision <- matrix(nrow = 0, ncol = length(results[[1]][[1]]$accuracy))
  recall <- matrix(nrow = 0, ncol = length(results[[1]][[1]]$accuracy))
  f1 <- matrix(nrow = 0, ncol = length(results[[1]][[1]]$accuracy))
  for (row in 1:length(results)){
    results_row = results[[row]]
    for (algorithm in length(results_row)){
      algorithm_row <- results_row[[algorithm]]
      #mean for macro scores
      accuracy <- rbind(accuracy, algorithm_row$accuracy)
      precision <- rbind(precision, lapply(algorithm_row$precision, mean))
      recall <- rbind(recall, lapply(algorithm_row$recall, mean))
      f1 <- rbind(f1, lapply(algorithm_row$f1, mean))
      
      
    }
  }
  ret <- c()
  ret$accuracy <- accuracy
  ret$precision <- precision
  ret$recall <- recall
  ret$f1 <- f1
  return(ret)
}

# 
# make_balanced <- function(data){
#   data_ret <- c()
#   data_ret$best <- c()
#   data_ret$data <- matrix(nrow = 0, ncol = ncol(data$data))
# 
#   algorithms <- levels(as.factor(data$best))
#   for (algorithm in algorithms){
#     
#     indices <- which(data$best == algorithm)[1:500]
#     
#     funcs <- as.data.frame(data$data)
#     funcs <- funcs$func
#     funcs <- funcs[indices]
#     new_best <- data$best[indices]
#     new_best <- new_best[!duplicated(funcs)]
#     new_best <- new_best[1:50]
#     new_data <- data$data[indices,]
#     new_data <- new_data[!duplicated(funcs),]
#     new_data <- new_data[1:50,]
#     #order(train_class)[!duplicated(sort(train_class))]
#     data_ret$best <- c(data_ret$best, new_best)
#     data_ret$data <- rbind(data_ret$data, new_data)
#     
#   }
#   
#   data_ret$data <- as.data.frame(data_ret$data)
#   return(data_ret)
# }



make_balanced <- function(data){
  data_ret <- c()
  data_ret$best <- c()
  data_ret$data <- matrix(nrow = 0, ncol = ncol(data$data))
  algorithms <- levels(as.factor(data$best))
  for (algorithm in algorithms){
    print(length(which(data$best == algorithm)))
    indices <- which(data$best == algorithm)[1:50]
    data_ret$best <- c(data_ret$best, data$best[indices])
    data_ret$data <- rbind(data_ret$data, data$data[indices,])
    
  }
  
  data_ret$data <- as.data.frame(data_ret$data)
  return(data_ret)
}

make_median <- function(data){
  funcs <- as.data.frame(data$data)
  funcs <- funcs$func
  funcs <- unique(funcs)
  data_ret <- c()
  data_ret$best <- c()
  data_ret$data <- matrix(nrow = 0, ncol = ncol(data$data))
  df <- as.data.frame(data$data)
  for (func in funcs){
    #print(func)
    
    indices <- which(df$func == func)
    
    if (length(indices) < 10){
      next()
    }
    
    
    
    new_best <- data$best[indices]
    
    if(length(unique(new_best)) > 1){
      print("different best")
    }
    
    new_data <- data$data[indices,]
    new_data <- colMedians(new_data)
    #order(train_class)[!duplicated(sort(train_class))]
    data_ret$best <- c(data_ret$best, new_best[[1]])
    data_ret$data <- rbind(data_ret$data, new_data)
    
  }
  
  return(data_ret)
}



calculate_accuracy_values<-function(data){
  precisions <- list()
  recalls <- list()
  f1s <- list()
  
  for (type in c("all", "Cols")){
    precision <- c()
    recall <-c() 
    f1 <- c()
    for (fold in c(1:10)){
      p_type <- data[[fold]]$precision[[type]]
      r_type <- data[[fold]]$recall[[type]]
      f1_type <- data[[fold]]$f1[[type]]
      
      precision <- c(precision, mean(p_type, na.rm=TRUE))
      recall <-c(recall, mean(r_type, na.rm=TRUE)) 
      f1 <- c(f1, mean(f1_type, na.rm=TRUE))
    }
    precisions[[type]] <- mean(precision, na.rm = TRUE)  
    recalls[[type]] <- mean(recall, na.rm = TRUE)   
    f1s[[type]] <- mean(f1, na.rm = TRUE) 
  }
  ret <- c()
  ret$precision <- precisions
  ret$recall <- recalls
  ret$f1 <- f1s
  
  return(ret)
  
}

#Main program
setwd("E:\\ML_Samples")

#columns <- readRDS("columns")
#[2] "ela_meta.quad_simple.adj_r2"    OK
#[3] "nbc.nb_fitness.cor"   OK          
#[4] "ela_meta.quad_w_interact.adj_r2" OK
#[5] "ela_meta.lin_simple.intercept"  OK
#[6] "ela_meta.lin_w_interact.adj_r2" OK
#[7] "ic.eps.max"  NO                   
#[8] "ela_distr.number_of_peaks" OK    
#[9] "ela_meta.lin_simple.adj_r2"  OK   
#[10] "limo.length.mean"  NO             
#[11] "ic.h.max" NO                      
#[12] "cm_angle.dist_ctr2best.mean"  NO  
#[13] "nbc.dist_ratio.coeff_var"  NO     
#[14] "ela_meta.lin_simple.coef.max"  NO 
#[15] "nbc.nn_nb.cor"  NO                
#[16] "ic.m0" NO

# 7/15



columns <- c("cm_angle.angle.mean", 
             "ela_distr.skewness", 
             "ela_distr.kurtosis", 
             "ela_distr.number_of_peaks",
             "ela_meta.lin_simple.adj_r2",
             "ela_meta.lin_simple.intercept",
             "ela_meta.lin_simple.coef.min",
             "ela_meta.quad_w_interact.adj_r2",
             "ela_meta.quad_simple.adj_r2",
             "ela_meta.lin_w_interact.adj_r2",
             "disp.ratio_mean_02",
             "disp.ratio_median_25",
             "nbc.nb_fitness.cor",
             "pca.expl_var_PC1.cov_init",
             "pca.expl_var.cov_init",
             "pca.expl_var.cor_init")
#Linear matrix factorization embeddings, X_temp is the data from the benchamrk problem genrator, number_of_singular_values is the specified number of singular values for which the low-rank approximation should be calculated, for your case put the number of ELA features, problems_names put from 1 till number of problems :)
#250


#folder <- "E:\\ML_features\\features"
#setwd("E:\\ML_features\\features")

#SET TRAIN AND TEST SET
#TRAIN: RANDOM
folder <- "E:\\ML_Samples_new_2\\features"
setwd("E:\\ML_Samples_new_2\\features")
#all_features <- read_features_performance(folder = folder, sample_size = 250)
#saveRDS(all_features, "all_features.rds")
all_features <- readRDS("all_features_new.rds")
funcs <- as.data.frame(all_features$data)
funcs <- funcs$func
all_features$data <- all_features$data[order(funcs),]
all_features$best <- all_features$best[order(funcs)]
all_features <- make_median(all_features)
all_features <- make_balanced(all_features)

best_data <- table(as.factor(all_features$best))

artificial_rows <- nrow(all_features$data)


folder <- "E:\\gecco_ml_samples\\features"
coco_features <- read_features_performance_coco(folder = folder, sample_size = 250)
coco_features <- as.data.frame(coco_features$data)

cnames <- colnames(coco_features)
cnames <- str_remove(cnames, "data.")
colnames(coco_features)<-cnames
best_coco <- readMat("E:\\coco_best.mat")$coco.best
algs <- c("ABC","ACO","CMAES","CSO","DE","FEP","GA","PSO","SA","Rand")
best_coco <- algs[best_coco]

best_coco <- get_best_coco(folder, best_coco)

coco_features$func <- get_func_coco(folder, best_coco)
combined_cols <- intersect(colnames(all_features$data), colnames(coco_features))

saveRDS(combined_cols,"E:\\ML_Cols.rds")
all_features$data <- all_features$data[,combined_cols]
coco_features <- coco_features[,combined_cols]
all_features$data <- rbind(all_features$data, coco_features)
all_features$best <- c(all_features$best, best_coco)

total = artificial_rows



X_temp <- all_features$data[1:total,]
best <- all_features$best[1:total]


X_temp <- as.data.frame(X_temp)
X_temp$basic.objective_min <- NULL
X_temp$basic.objective_max <- NULL
X_temp$basic.upper_max <- NULL
X_temp$basic.upper_min <- NULL
X_temp$basic.lower_min <- NULL
X_temp$basic.lower_max<- NULL
X_temp$basic.blocks_min <- NULL
X_temp$basic.blocks_max <- NULL
X_temp$basic.cells_total <- NULL
X_temp$basic.cells_filled <- NULL
X_temp$basic.minimize_fun <- NULL
X_temp$basic.costs_fun_evals <- NULL
X_temp$basic.dim <- NULL
X_temp$basic.observations <- NULL


X_temp$basic.lower_max <- NULL
X_temp$basic.lower_min <- NULL
X_temp$basic.costs_runtime <- NULL
X_temp$pca.costs_runtime <- NULL
X_temp$pca.costs_fun_evals <- NULL
X_temp$nbc.costs_fun_evals <- NULL
X_temp$nbc.costs_runtime<- NULL
X_temp$limo.costs_runtime<- NULL
X_temp$limo.costs_fun_evals<- NULL
X_temp$disp.costs_fun_evals<- NULL
X_temp$disp.costs_runtime<- NULL
X_temp$ic.costs_fun_evals<- NULL
X_temp$ic.costs_runtime<- NULL
X_temp$ela_meta.costs_fun_evals<- NULL
X_temp$ela_level.costs_fun_evals<- NULL
X_temp$ela_meta.costs_runtime<- NULL
X_temp$ela_level.costs_runtime<- NULL
X_temp$cm_grad.costs_fun_evals <- NULL
X_temp$cm_grad.costs_runtime<- NULL
X_temp$cm_angle.costs_runtime <- NULL
X_temp$cm_angle.costs_fun_evals<- NULL
X_temp$cm_grad.costs_fun_evals <- NULL



#names_to_exclude <- readRDS("exclude")
#for (name in names_to_exclude[1:5]){
#  X_temp[[name]] <- NULL
#}



X_temp <- sapply(X_temp, as.numeric)
X_temp <- as.data.frame(X_temp)

#w <- which(best == "CMAES" | best == "GA")
#best <- best[w]
#X_temp <- X_temp[w,]

#X_temp <- normalize_data(X_temp, type = "minmax")


best <- as.numeric(as.factor(best))
classes <- best
classes <- as.factor(classes)
X_temp$class <- classes
#X_temp <- X_temp[ , colSums(is.na(X_temp)) == 0]
#X_temp <- X_temp[ , colSums(is.nan(X_temp)) == 0]

#shuffle rows
X_temp <- X_temp[sample(nrow(X_temp)),]



#folds <- createFoldsCustom(X_temp, k = 10)
number_of_splits <- 10
folds <- 1:nrow(X_temp)
folds <- split(folds,cut(seq_along(folds),number_of_splits,labels = FALSE))
X_temp$func <- NULL


NUMBER_OF_ALGORITHMS = 1
TRIALS_PER_ALGORITHM = 7
NUMBER_OF_FOLDS = 10
NUMBER_OF_COLUMNS = NUMBER_OF_ALGORITHMS * TRIALS_PER_ALGORITHM
results_matrix = matrix(nrow=NUMBER_OF_FOLDS, ncol = NUMBER_OF_COLUMNS)
full_results <- list()
#colnames(results_matrix) <- c("rf2", "rf5", "rf10", "rf15", "rf20", "rfAll", "rfCols", "knn2", "knn5", "knn10", "knn15", "knn20", "knnAll", "knnCols")
matrix_index <- 1
all_results <- list()
shap_results_artificial <- list()


X_temp <- readRDS("E:\\transfer_datasets\\train.rds")
X_temp <- X_temp[sample(nrow(X_temp)),]
for (fold in folds){
  print(matrix_index)
  train_rows <- setdiff(1:nrow(X_temp), fold)
  test_rows <- fold
  
  #train_rows = 1:total
  #test_rows = (total + 1):nrow(X_temp)
  
  
  
  train <- X_temp[train_rows,]
  #train <- normalize_data(train, type = "minmax")
  train <- train[complete.cases(train),]
  
  test <- X_temp[test_rows,]
  #test <- normalize_data(test, type = "minmax")
  test <- test[complete.cases(test),]
  #TEST_ROWS <- 1:(nrow(test)/2)
  #VALIDATION_ROWS <- ((nrow(test)/2) + 1):nrow(test)
  #test <- test[TEST_ROWS,]
  #validation <- test[VALIDATION_ROWS,]
  validation <- test
  
  # train_pca <- train
  # train_pca_classes <- train_pca$class
  # train_pca$class <- NULL
  # train_pca_transform <- prcomp(train_pca)
  # train_pca <- train_pca_transform$x
  # train_pca <- as.data.frame(train_pca)
  # train_pca$class <- train_pca_classes
  # 
  # test_pca_classes <- test$class
  # test_pca <- test
  # test_pca$class<- NULL
  # test_pca <- predict(train_pca_transform, test_pca)
  # test_pca <- as.data.frame(test_pca)
  # test_pca$class <- test_pca_classes
  # 
  # 
  # train_data_pca <- c()
  # train_data_pca$all <- train_pca
  # train_data_pca$"2" <- train_pca[,c(1:2,ncol(train_pca))]
  # train_data_pca$"5" <- train_pca[,c(1:5,ncol(train_pca))]
  # train_data_pca$"10" <- train_pca[,c(1:10,ncol(train_pca))]
  # train_data_pca$"15" <- train_pca[,c(1:15,ncol(train_pca))]
  # train_data_pca$"20" <- train_pca[,c(1:20,ncol(train_pca))]
  # train_data_pca$Cols <- train_pca[,c(1:40,ncol(train_pca))]
  # 
  # 
  # 
  # 
  # train_SVD <- train
  # train_SVD_classes <- train_SVD$class
  # train_SVD$class <- NULL
  # train_SVD <- as.matrix(train_SVD)
  # train_SVD_transform<-linear_matrix_factorization_embeddings(train_SVD,1:nrow(train_SVD),ncol(train_SVD))
  # 
  # train_SVD<-train_SVD_transform$problems_embeded
  # train_SVD <- as.data.frame(train_SVD)
  # U<-train_SVD_transform$U
  # Sigma<-train_SVD_transform$Sigma
  # V_t<-train_SVD_transform$V_t
  # inv_Sigma<-diag(1/diag(Sigma))
  # 
  # train_SVD$class <- train_SVD_classes
  # train_data_SVD <- c()
  # train_data_SVD$all <- train_SVD
  # train_data_SVD$"2" <- train_SVD[,c(1:2,ncol(train_SVD))]
  # train_data_SVD$"5" <- train_SVD[,c(1:5,ncol(train_SVD))]
  # train_data_SVD$"10" <- train_SVD[,c(1:10,ncol(train_SVD))]
  # train_data_SVD$"15" <- train_SVD[,c(1:15,ncol(train_SVD))]
  # train_data_SVD$"20" <- train_SVD[,c(1:20,ncol(train_SVD))]
  # train_data_SVD$Cols <- train_SVD[,c(1:40,ncol(train_SVD))]
  # 
  # #SVD Test data
  # test_SVD_classes <- test$class
  # test_SVD <- test
  # test_SVD$class<- NULL  
  # test_SVD <- as.matrix(test_SVD)
  # test_SVD_mapped <- list()
  # for(i in 1:nrow(test_SVD)){
  #   test_SVD_mapped[[i]]<-test_SVD[i,]%*%t(V_t)%*%inv_Sigma
  # }
  # 
  # test_SVD<-matrix(unlist(test_SVD_mapped)[!is.na(unlist(test_SVD_mapped))], ncol = length(test_SVD_mapped[[i]]), byrow = T)
  # test_names<-1:nrow(test_SVD)
  # rownames(test_SVD)<-test_names
  # test_SVD <- as.data.frame(test_SVD)
  # test_SVD$class <- test_SVD_classes
  # 
  # 
  rf = randomForest(class ~ ., data=train, ntree=1000, importance=TRUE)
  importance <- rf$importance
  #importance <- importance[order(importance[,12], decreasing = TRUE),]
  importance <- importance[order(importance[,ncol(importance)], decreasing = TRUE),] #TODO: check if this works on normal data, change back if it doesnt (last one should be meandecreaseGini)
  importanceRows <- rownames(importance)
  importanceRows <- c("class", importanceRows)
  
  columns <- intersect(colnames(train), columns)
  columns <- c(columns, "class")
  columns <- setdiff(columns, "class.1")
  
  #we don't use this anymore
  train2 <- train[importanceRows[1:3]]
  train5 <- train[importanceRows[1:3]]
  train10 <- train[importanceRows[1:3]]
  train15 <- train[importanceRows[1:3]]
  train20 <- train[importanceRows[1:3]]
  trainCols <- train[columns]
  
  
  train_data <- c()
  train_data$all <- train
  train_data$"2" <- train2
  train_data$"5" <- train5
  train_data$"10" <- train10
  train_data$"15" <- train15
  train_data$"20" <- train20
  train_data$Cols <- trainCols
  
  
  #define models here
  rf_functional = train_ml(function(x){randomForest(class ~ ., data=x, ntree=1000)}, train_data)
  rf_results = test_ml(rf_functional, test, validation, "rf", train_data)
  shap_results_artificial[[matrix_index]] <- rf_results
  matrix_index <- matrix_index + 1
}
#average across all folds
#each row represents a class (algorithm) from 1 to 10
#average_contribution <- Reduce("+", shap_results) / length(shap_results)
#saveRDS(average_contribution, "E:\\shap_artificial_avg.rds")

saveRDS(shap_results_artificial, "E:\\shap_artificial.rds")


shap_results_artificial <- readRDS("E:\\shap_artificial.rds")

all_results <- list()
correct_results <- list()
wrong_results <- list()
for (iter in 1:10){
  all_results[[iter]] <- shap_results_artificial[[iter]]$all
  correct_results[[iter]] <- shap_results_artificial[[iter]]$correct
  wrong_results[[iter]] <- shap_results_artificial[[iter]]$wrong
}
iter_average <- function(data){
  row_totals <- rep(0,10)
  total <- NA
  for (i in 1:10){
    current_data <- data[[i]]
    #gives 1 to a row that has data, and 0 to a row that doesnt
    non_na <- as.numeric(!is.na(rowSums(current_data)))
    row_totals <- row_totals + non_na
    current_data[is.na(current_data)] <- 0
    if(is.na(total)){
      total <- current_data
    } else {
      total <- total + current_data
    }
  }
  return(total/row_totals)
  
}


average_all_artificial <- iter_average(all_results)
average_correct_artificial <- iter_average(correct_results)
average_wrong_artificial <- iter_average(wrong_results)


colnames(average_correct_artificial) <- colnames(average_wrong_artificial)
average_correct_artificial<-colMeans(average_correct_artificial, na.rm = TRUE)
average_wrong_artificial<-colMeans(average_wrong_artificial, na.rm = TRUE)

